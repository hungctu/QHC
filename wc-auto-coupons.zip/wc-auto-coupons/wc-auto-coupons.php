<?php
/**
 * Plugin Name: WooCommerce Auto Coupons Sync
 * Description: Tự động đồng bộ mã giảm giá từ server API vào WooCommerce.
 * Version: 1.0
 * Author: Hung Nguyen
 */

if (!defined('ABSPATH')) {
    exit; // Chặn truy cập trực tiếp
}

// Hook vào admin menu
add_action('admin_menu', 'wc_auto_coupons_menu');

function wc_auto_coupons_menu() {
    add_menu_page(
        'Auto Coupons Sync',
        'Auto Coupons Sync',
        'manage_options',
        'wc-auto-coupons',
        'wc_auto_coupons_page'
    );
}

// Giao diện trang plugin
function wc_auto_coupons_page() {
    ?>
    <div class="wrap">
        <h1>Đồng bộ mã giảm giá từ API</h1>
        <form method="post" action="">
            <label for="coupon_group">Chọn nhóm:</label>
            <select name="coupon_group" id="coupon_group">
                <option value="QHC_A">QHC_A (0.001 QHC)</option>
                <option value="QHC_B">QHC_B (0.01 QHC)</option>
                <option value="QHC_C">QHC_C (0.1 QHC)</option>
                <option value="QHC_D">QHC_D (1 QHC)</option>
                <option value="all">Tất cả</option>
            </select>
            <button type="submit" name="sync_coupons" class="button button-primary">Đồng bộ ngay</button>
        </form>
        <?php
        if (isset($_POST['sync_coupons'])) {
            $group = sanitize_text_field($_POST['coupon_group']);
            wc_auto_coupons_sync($group);
        }
        ?>
    </div>
    <?php
}

// Gửi request đến API và cập nhật WooCommerce
function wc_auto_coupons_sync($group) {
    $api_url = "http://127.0.0.1:5000/code/getWPCoupon"; // URL API mới
    $response = wp_remote_post($api_url, array(
        'body'    => json_encode(array('code' => $group)),
        'headers' => array('Content-Type' => 'application/json'),
        'timeout' => 120,
    ));

    if (is_wp_error($response)) {
        echo "<p>Lỗi kết nối API.</p>";
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (!$data || !$data['status']) {
        echo "<p>Lỗi: Không lấy được dữ liệu từ API.</p>";
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . "posts";

    foreach ($data['result'] as $coupon) {
        $code = sanitize_text_field($coupon['code']);
        $amount = floatval($coupon['amount']);

        // Kiểm tra xem coupon đã tồn tại chưa
        $existing_coupon_id = $wpdb->get_var($wpdb->prepare("
            SELECT ID FROM $table_name WHERE post_title = %s AND post_type = 'shop_coupon' LIMIT 1
        ", $code));

        if ($existing_coupon_id) {
            // Kiểm tra xem coupon đã được sử dụng chưa
            $used = get_post_meta($existing_coupon_id, 'usage_count', true);
            if ($used && intval($used) > 0) {
                echo "<p>Coupon $code đã được sử dụng, không cập nhật.</p>";
                continue;
            }

            // Cập nhật giá trị giảm giá
            update_post_meta($existing_coupon_id, 'coupon_amount', $amount);
            echo "<p>Cập nhật coupon $code thành $amount.</p>";
        } else {
            // Tạo mới coupon
            $coupon_id = wp_insert_post(array(
                'post_title'   => $code,
                'post_content' => '',
                'post_status'  => 'publish',
                'post_author'  => 1,
                'post_type'    => 'shop_coupon'
            ));

            update_post_meta($coupon_id, 'discount_type', 'fixed_cart'); // Giảm giá cố định
            update_post_meta($coupon_id, 'coupon_amount', $amount);
            update_post_meta($coupon_id, 'usage_limit', 1); // Giới hạn 1 lần dùng
            update_post_meta($coupon_id, 'individual_use', 'yes'); // Chỉ dùng 1 mã/lần

            echo "<p>Thêm mới coupon $code - $amount.</p>";
        }
    }
}
