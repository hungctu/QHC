<?php
/**
 * Plugin Name: WooCommerce Update Code Used
 * Description: Gửi code và order_id đến server ngay khi đơn hàng được tạo.
 * Version: 1.5
 * Author: Hung Nguyen
 */

if (!defined('ABSPATH')) {
    exit;
}

// Hook vào sự kiện tạo đơn hàng mới
add_action('woocommerce_new_order', 'send_code_to_api_on_new_order', 10, 1);

function send_code_to_api_on_new_order($order_id) {
    $order = wc_get_order($order_id);

    if (!$order) {
        error_log('Không tìm thấy đơn hàng #' . $order_id);
        return;
    }

    // Lấy mã giảm giá đã sử dụng
    $coupons = $order->get_coupon_codes();

    if (empty($coupons)) {
        error_log('Không tìm thấy mã giảm giá nào trong đơn hàng #' . $order_id);
        return;
    }

    foreach ($coupons as $code) {
        // Chuyển mã giảm giá thành chữ hoa
        $code = strtoupper($code);

        $data = json_encode([
            'code' => $code,
            'order_id' => $order_id
        ]);

        error_log('Đang gửi dữ liệu: ' . $data);

        $response = wp_remote_post('http://127.0.0.1:5000/code/updateCodeUsedOnWP', [
            'method'    => 'POST',
            'body'      => $data,
            'headers'   => [
                'Content-Type' => 'application/json',
                'User-Agent'   => $_SERVER['HTTP_USER_AGENT']
            ],
            'timeout'   => 30
        ]);

        // Kiểm tra kết quả gửi
        if (is_wp_error($response)) {
            error_log('Lỗi gửi API: ' . $response->get_error_message());
        } else {
            $response_code = wp_remote_retrieve_response_code($response);
            $response_body = wp_remote_retrieve_body($response);
            error_log('Phản hồi từ server: HTTP ' . $response_code . ' - ' . $response_body);
        }
    }
}
