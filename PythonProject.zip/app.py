from flask import Flask, request, jsonify
from flask_cors import CORS

from codeManager import codeManager

app = Flask(__name__)
CORS(app)

@app.route('/code/addNumsCode', methods=['POST'])
def addNumsCode():
    try:
        data = request.json
        type = str(data.get('type','qhc_a'))
        nums = int(data.get('nums', 10))

        cm = codeManager()
        result = cm.addNumsCode(nums, type)
        return jsonify(result),200
    except Exception as e:
        print(e)
        return jsonify({
            "status": False,
            "error": str(e)
        }), 500

@app.route('/code/getCode', methods=['GET'])
def getCode():
    try:
        ip = request.remote_addr
        cm = codeManager()
        user_agent = request.headers.get('User-Agent')
        print(f"User-Agent: {user_agent}")
        result = cm.getCode(user_agent)
        return jsonify(result)
    except Exception as e:
        print(e)
        return jsonify({
            "status": False,
            "error": str(e)
        }), 500

@app.route('/code/useCode', methods=['POST'])
def useCode():
    try:
        data = request.json
        code = str(data.get('code', 'ABCDE'))
        address = str(data.get('address', '0x000000000000000000000000'))

        cm = codeManager()
        result = cm.UseCode(code, address)
        return jsonify(result),200
    except Exception as e:
        print(e)
        return jsonify({
            "status": False,
            "error": str(e)
        }), 500

@app.route('/code/codeQuantity', methods=['POST'])
def codeQuantity():
    try:
        data = request.json
        code = str(data.get('code', 'ABCDE'))

        cm = codeManager()
        result = cm.getUnit(code)
        return jsonify(result),200
    except Exception as e:
        print(e)
        return jsonify({
            "status": False,
            "error": str(e)
        }), 500

@app.route('/', methods=['GET'])
def hello():
    return "hello"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)