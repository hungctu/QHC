from database import Database
from dotenv import load_dotenv
import os

load_dotenv()

class transferModel:
    def __init__(self):
        self.db = Database()

    def addTransfer(self,wallet_id,code,QHC,hash):
        try:
            query = 'INSERT INTO transfers(`main_wallet_address`, `wallet_id`, `code`, `QHC`, `Tx_hash`) VALUES (%s,%s,%s,%s,%s)'
            self.db.execute(query,(os.getenv('MAIN_WALLET_ADDRESS'),wallet_id,code,QHC,hash,))
            return True
        except Exception as e:
            print(f"Error when add Transfer data to DB: {e}")
            return False